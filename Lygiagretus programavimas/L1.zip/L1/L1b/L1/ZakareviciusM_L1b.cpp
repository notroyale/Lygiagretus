/*
* Mantvydas Zakarevi�ius IFF-4/2
*
* 1. Kokia tvarka startuoja procesai? Galimi atsakymo variantai: tokia, kokia u�ra�yti, atsitiktine, atvirk��ia.
* 		Atsakymas: atsitiktine.
* 2. Kokia tvarka vykdomi procesai? Galimi atsakymo variantai: tokia, kokia startuoja, atsitiktine, atvirk��ia.
* 		Atsakymas: atsitiktine.
* 3. Kiek iteracij� i� eil�s padaro vienas procesas? Galimi atsakymo variantai: vienos dal�, vien� pilnai, visas,
* atsitiktin� skai�i�.
* 		Atsakymas: atsitiktin� skai�i�.
* 4. Kokia tvarka to paties duomen� masyvo elementai sura�omi � rezultat� masyv�? Galimi atsakymo variantai:
* tokia, kokia sura�yti duomen� masyve, atsitiktine, atvirk��ia.
* 		Atsakymas: atsitiktine.
*
*/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <omp.h>

using namespace std;

//Gij� skai�ius
int thread_amount = 0;

//Bendra strukt�ra P
struct ThreadStruct {
	int thread_number;
	string name;
	int wins;
	double points;
};

/*
 * Nuskaito duomenis i� duomen� failo � masyvus
 *
 * @param S - string tipo masyvas
 * @param I - int tipo masyvas
 * @param D - double tipo masyvas
 */
void ReadData(string S[], int I[], double D[]);
/*
 * I�veda duomenis i� masyv� � rezultat� fail�
 *
 * @param S - string tipo masyvas
 * @param I - int tipo masyvas
 * @param D - double tipo masyvas
 */
void WriteData(string S[], int I[], double D[]);
/*
 * Vykdo gijas
 *
 * @param S - string tipo masyvas
 * @param I - int tipo masyvas
 * @param D - double tipo masyvas
 * @param P - ThreadStruct tipo masyvas
 * @param thread_identifier - P masyvo element� identifikatorius
 * @return - void
 */
void ExecuteThreads(string S[], int I[], double D[], ThreadStruct P[], int & thread_identifier);
/*
 * I�veda duomenis i� bendro gij� masyvo � rezultat� fail�
 *
 * @param P - ThreadStruct tipo masyvas
 * @param thread_identifier - P masyvo element� identifikatorius
 * @return - void
 */
void WriteThreads(ThreadStruct P[], int thread_identifier);

int main() {

	//Nustato lokalizacij�, kad tinkamai b�t� nuskaitomi lietuvi�ki ra�menys
	setlocale(LC_ALL, "");

	//Duomen� masyvai: S - string, I - int, D - double
	string S[20];
	int I[20];
	double D[20];

	//Bendras masyvas sudarytas i� strukt�ros ThreadStruct ir reik�m�m sud�ti papildomas masyvo identifikatorius
	ThreadStruct P[20];
	int thread_identifier = 0;

	//Vykdomos funkcijos: nuskaityti duomenis � masyvus, tada tuos duomenis i�vesti � duomen� fail�
	ReadData(S, I, D);
	WriteData(S, I, D);

	//Vykdomos funkcijos: vykdyti gijas, tada j� veiksm� rezultat� i�spausdinti � fail�
	ExecuteThreads(S, I, D, P, thread_identifier);
	WriteThreads(P, thread_identifier);

	cout << "Programa baig� darb�!" << endl;

	return 0;
}

void ReadData(string S[], int I[], double D[]) {

	ifstream  readStream("ZakareviciusM_L1b.dat.txt");

	//Kol yra tinkamai �vest� objekt� ir nepasiekia limito (20), juos �ra�o � masyv�
	for (int i = 0; !readStream.eof() && i < 20; i++) {
		readStream >> S[i] >> I[i] >> D[i];
		thread_amount++;
	}

	readStream.close();

	return;
}

void WriteData(string S[], int I[], double D[]) {

	ofstream writeStream("ZakareviciusM_L1b.rez.txt");

	//I�vedamos stulpeli� antra�t�s
	writeStream << setw(3) << "Nr." << " " << setw(14) << left << "Pavard�" << " " << setw(7) << "Pergal�s" << " " << setw(5) << "Ta�kai" << endl;

	//Kol yra tinkamai �vest� objekt� ir nepasiekia limito (20), juos �ra�o � fail� pagal stulpelius
	for (int i = 0; S[i] != "" && I[i] >= 0 && D[i] >= 0 && i < 20; i++) {
		writeStream << setw(2) << right << i + 1 << ") " << setw(20) << left << S[i] << " " << setw(2) << right << I[i] << "  " << setw(5) << right << fixed << setprecision(2) << D[i] << endl;
	}

	//I�vedama papildoma tu��ia eilut�
	writeStream << endl;

	writeStream.close();

	return;
}

void ExecuteThreads(string S[], int I[], double D[], ThreadStruct P[], int & thread_identifier) {

	//Gijos identifikacinis numeris
	int thread_number = 0;

	//Nustatomas gij� kiekis
	omp_set_num_threads(thread_amount);

	int thread_internal_identifier = thread_identifier;

	//Lygiagretus kodas
	#pragma omp parallel private(thread_number, thread_internal_identifier)
	{
		//Papildomas vidinis identifikatorius, kad teisingai nuskaityt� visas reik�mes
		thread_internal_identifier = thread_identifier++;

		//Gaunamas gijos numeris
		thread_number = omp_get_thread_num();

		//�ra�omos reik�m�s � bendr� masyv� P
		P[thread_internal_identifier].thread_number = thread_number;
		P[thread_internal_identifier].name = S[thread_number];
		P[thread_internal_identifier].wins = I[thread_number];
		P[thread_internal_identifier].points = D[thread_number];
	}

	return;
}

void WriteThreads(ThreadStruct P[], int thread_identifier) {

	ofstream writeStream("ZakareviciusM_L1b.rez.txt", fstream::app);

	//I�vedamos stulpeli� antra�t�s
	writeStream << setw(3) << "Nr." << " " << setw(4) << "Gija" << " " << setw(14) << left << "Pavard�" << " " << setw(7) << "Pergal�s" << " " << setw(5) << "Ta�kai" << endl;

	//Kol yra tinkam� reik�mi� P masyve, juos �ra�o � fail� pagal stulpelius
	for (int i = 0; P[i].thread_number >= 0 && P[i].name != "" && P[i].wins >= 0 && P[i].points >= 0 && i < thread_identifier; i++) {
		writeStream << setw(2) << right << i + 1 << ")   " << setw(2) << right << P[i].thread_number << " " << setw(20) << left << P[i].name << " " << setw(2) << right << P[i].wins << "  " << setw(5) << right << fixed << setprecision(2) << P[i].points << endl;
	}

	writeStream.close();

	return;
}